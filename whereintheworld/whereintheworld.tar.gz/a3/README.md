COMP20 Assignment 3 by Leo Choi

1. all aspects have been implemented correctly -- I added node_modules to .gitignore, internet seems divided about that
2. Ming helped me understand node.js and how it's event based
3. 30 hours, maybe? hard to estimate...