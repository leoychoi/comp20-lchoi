// Express initialization
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var http = require('http');

// Mongo initialization, setting up a connection to a MongoDB  (on Heroku or localhost)
var mongoUri = process.env.MONGOLAB_URI ||
    process.env.MONGOHQ_URL ||
    'mongodb://localhost:3000/a3'; // comp20 is the name of the database we are using in MongoDB
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
});

var characters = [];
var students = [];

app.use(bodyParser.json());
app.use(bodyParser.urlencoded( {extended: true} ));
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.post('/sendLocation', function (request, response) {
    var login = request.body.login;
    var lat = parseFloat(request.body.lat);
    var lng = parseFloat(request.body.lng);
    if (!login || !lat|| !lng) {
	response.status(400);
	response.send("invalid post request");
    } else {
	timestamp = new Date().toGMTString();
	db.collection('locations', function (error, collection) {
	    collection.insert({'login': login, 'lat': lat, 'lng': lng, 'created_at': timestamp}, function (fail, success) {
		if (!fail) {
		    collection.find({}, {"sort":['datefield', 'asc']}).limit(100).toArray(function(err, documents) { 
			    students = documents;
			    retVal = JSON.stringify({'characters': characters, 
						     'students': students});
			    response.send(retVal);
			}
		    );
		}
	    });
	});
    }
});

app.get('/locations.json', function (request, response) {
    db.collection('locations', function (error, collection) {
//	var login = request.query.login;
	var login = request.param('login');
	if (!login) {
	    var empt = [];
	    response.send(JSON.stringify(empt));
	} else {
	    collection.find({login: login}, {"sort":['datefield', 'asc']}).toArray(function(err, documents) {
		students = documents;
		response.send(JSON.stringify(students));
	    });
	}
    });
});

app.get('/redline.json', function (request, response) {
    var data = '';
    http.get("http://developer.mbta.com/lib/rthr/red.json",
	     function(apiresponse) {
	apiresponse.on('data', function(chunk) {
	    data += chunk;
	});
	apiresponse.on('end', function() {
	    response.send(data);
	});
    }).on('error', function(error) {
	response.send(500);
    });
});


app.get('/', function (request, response) {
    db.collection('locations', function (error1, collection) {
	response.set('Content-Type', 'text/html');
	indexHTML = "<html><head><title>Check-ins</title></head><body><h3>Check-ins</h3>"
	var cursor = collection.find({}, {"sort":['datefield', 'asc']});
	cursor.each(function(err, item) {
	    if (item == null) {
		indexHTML += "</body></html>";
		response.send(indexHTML);
	    } else {
		indexHTML += "<p>Login: " + item.login + " ";
		indexHTML += "Time: " + item.created_at + " ";
		indexHTML += "Latitude: " + item.lat + " ";
		indexHTML += "Longitude: " + item.lng + "</p><br>";
	    }
	});
    });
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);


